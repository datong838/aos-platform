---
name: palantir-topic-docx
description: "Generate a standard Chinese PRD-style Word document from a Palantir Foundry topic Markdown documentation directory. Resolves and embeds referenced images, auto-discovers document ordering via frontmatter previous/next links, and produces a professional A4 document with cover page, table of contents, and formatted content. Use this skill when asked to generate a Word document from Palantir Foundry documentation topics in the docs/palantier repository. Trigger keywords: 生成word文档, 生成专题文档, Palantir 文档转 Word, 专题文档生成, generate topic docx."
agent_created: true
---

# Palantir Topic Word Document Generator

Generate standard PRD-style Word documents from Palantir Foundry Markdown documentation topic directories.

## When to Use

- User asks to generate a Word document from a Palantir Foundry documentation topic
- User provides a topic directory path and wants a .docx output
- User says things like "把这个专题生成 Word 文档", "generate docx for this topic"

## Input Requirements

The topic directory must contain:
- Multiple `.md` files with YAML frontmatter (containing `title`, optionally `previous`/`next`)
- Image references in Markdown (`![alt](path)`) or HTML (`<img src="...">`) format

## Image Resolution

The script auto-discovers images using multiple strategies:
1. Absolute paths (e.g. `/resources/foundry/{topic}/xxx.png`) → resolved from `docs/palantier/resources/`
2. Relative paths (e.g. `../../../images/foundry/{topic}/xxx.png`) → resolved from the topic's images directory
3. Filename-only fallback → global search across `images/` and `resources/` directories

## Usage

Run the script with:

```bash
python {SKILL_ROOT}/scripts/generate_topic.py <topic_dir> [--output-dir <output_dir>] [--topic-name <name>]
```

### ### Arguments

- **topic_dir** (required): Path to the topic's Markdown files directory
- **--output-dir / -o** (optional): Output directory, defaults to the user's palantier/prddetail path
- **--topic-name / -n** (optional): Topic name for filename and cover, defaults to the last component of topic_dir

### Examples

```bash
# Generate from action-types topic
python {SKILL_ROOT}/scripts/generate_topic.py \
  /Users/ddt/work/projects/ai_agent/docs/palantier/foundry/pages/zh/foundry/action-types

# Specify custom output and name
python {SKILL_ROOT}/scripts/generate_topic.py \
  /Users/ddt/work/projects/ai_agent/docs/palantier/foundry/pages/zh/foundry/object-types \
  --output-dir /Users/ddt/work/projects/ai_agent/docs/palantier/prddetail \
  --topic-name object-types
```

## Output

The script produces a `.docx` file with:
- **Cover page**: Topic name (English), display name (Chinese-style), brief description
- **Table of contents**: Auto-generated from frontmatter titles
- **Body**: Each Markdown file as a separate chapter with:
  - H1 from frontmatter `title`
  - H2/H3 from `##`/`###` headings
  - Inline formatting: bold (`**`), code (`` ` ``), links
  - Images: centered with "图：{alt}" captions
  - Tables: styled with Light Grid Accent 1
  - Bullet/numbered lists
  - Blockquotes
  - Code blocks (Consolas font, gray background)

## Formatting Details

- Page: A4 (21cm × 29.7cm)
- Font: Microsoft YaHei (微软雅黑), 10.5pt body, 18/15/13pt headings
- Heading colors: Blue (#003366, #00467F, #005A96)
- Line spacing: 1.5×
- Images: auto-scaled to max 5.5" wide, 4.5" tall, centered

## Compatibility

Generated .docx files are compatible with:
- **WPS Office for Mac/Windows** (recommended for Mac users)
- Microsoft Word for Windows
- LibreOffice
- Office 365 Web

Mac Microsoft Word has known compatibility issues with python-docx generated inline images. Use WPS Office as the preferred viewer on macOS.

## Dependencies

Requires Python packages: `python-docx`, `Pillow`

Install with:
```bash
pip install python-docx Pillow
```

## Known Limitations

1. Images under `/resources/` path may not be available locally — they appear as `[图片未找到]` placeholders
2. Callout blocks (`:::callout{...}`) are stripped to plain text; styling hints (warning/info) are lost
3. Internal cross-page links render as plain text (no hyperlinks in Word)
4. Complex nested list structures may flatten
